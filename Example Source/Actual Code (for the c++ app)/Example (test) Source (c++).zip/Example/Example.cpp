// Example.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include "resource.h"


#define sAppName "Multiple TextBox Example" // The Application Name (For captions etc...)
#define sClassName "MTBExample" // The Class Name!

HINSTANCE hInstance; // Global Variable for Instances
static HWND MainHwnd; // Main Window Handle

#define IDC_EDIT1 1
#define IDC_EDIT2 2
#define IDC_EDIT3 3
#define IDC_INFO 4

HWND TXT1;
HWND TXT2;
HWND TXT3;
HWND CMDINFO;


static LRESULT CALLBACK mainWindowProc(HWND hwnd, UINT msg, WPARAM wparam,LPARAM lparam);

int APIENTRY WinMain(HINSTANCE hinst, HINSTANCE hprevinst, LPSTR lpCmdLine, int cmdShow)
{
 	if (hprevinst == NULL) // If the program isn't open
	{
		WNDCLASS wclass;
		memset (&wclass, 0, sizeof(wclass));
		wclass.style = CS_HREDRAW | CS_VREDRAW;
		wclass.lpfnWndProc = mainWindowProc;
		wclass.hInstance = hinst;
		wclass.hIcon = LoadIcon(hinst,MAKEINTRESOURCE(IDI_ICON1)); 
		wclass.hCursor = LoadCursor (NULL, IDC_ARROW);
		wclass.hbrBackground = (HBRUSH)GetStockObject(LTGRAY_BRUSH);
		wclass.lpszClassName = sClassName;
		if (!RegisterClass (&wclass)) return 0;
	}

	HWND hwnd = CreateWindow(sClassName,sAppName,WS_OVERLAPPED | WS_MINIMIZEBOX |WS_VISIBLE | WS_CAPTION | WS_SYSMENU | WS_DLGFRAME | WS_BORDER,
		CW_USEDEFAULT,CW_USEDEFAULT,275,175,0,0,hinst,0);
	hInstance = hinst;
	ShowWindow(hwnd, 1); // Show the window
	MainHwnd = hwnd;
	MSG msg;

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

	return msg.wParam;
}



static LRESULT CALLBACK mainWindowProc(HWND hwnd, UINT msg, WPARAM wparam,LPARAM lparam)
{
	switch (msg)
	{
	case WM_DESTROY:
		{
			PostQuitMessage(0);
		}
	case WM_CREATE:
		{
			if (TXT1)
			{
				break;
			}

			TXT1 = CreateWindow("Edit","TextBox 1",WS_CHILD | WS_VISIBLE | ES_MULTILINE | WS_VSCROLL ,5,5,250,25,hwnd,(HMENU)IDC_EDIT1,hInstance,0);
			TXT2 = CreateWindow("Edit","TextBox 2",WS_CHILD | WS_VISIBLE | ES_MULTILINE | WS_VSCROLL ,5,35,250,25,hwnd,(HMENU)IDC_EDIT2,hInstance,0);
			TXT3 = CreateWindow("Edit","TextBox 3",WS_CHILD | WS_VISIBLE | ES_MULTILINE | WS_VSCROLL ,5,65,250,25,hwnd,(HMENU)IDC_EDIT3,hInstance,0);
			CMDINFO = CreateWindow("Button","&Info",WS_CHILD | WS_VISIBLE,55,100,125,25,hwnd,(HMENU)IDC_INFO,hInstance,0);
		}
	case WM_COMMAND:
		{
			switch(HIWORD(wparam))
			{
			case BN_CLICKED:
				{
					switch(LOWORD(wparam))
					{
					case IDC_INFO:
						{
							MessageBox(hwnd,"This program was written in pure Win32 C++. Anyway, you can see how these three textboxes are all on the same window, so you can still get the info for TextBox3 by including TextBox2 in the second HWND param, and Then in the TextBox2 include TextBox1. See, most languages use CreateWindow to make buttons and textboxes: by specifying the class name. Well, except for vb apps, the normal class name for a textbox would be Edit. Yet again, vb changes it to some cheezy thunder thing. -- Jaime Muscatelli",sAppName,MB_OK);
							break;
						}
					}
				}
			}
		}
	default:
		{
			return DefWindowProc(hwnd,msg,wparam,lparam);
		}
	}
	return false;
}